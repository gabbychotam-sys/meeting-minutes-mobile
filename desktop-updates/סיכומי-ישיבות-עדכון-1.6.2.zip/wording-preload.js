const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('wordingAPI', {
  choose: (index) => ipcRenderer.send('wording:choose', index)
});
