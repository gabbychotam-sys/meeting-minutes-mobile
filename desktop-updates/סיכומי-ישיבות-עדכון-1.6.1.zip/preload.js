const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('MeetingMinutes', {
  isElectron: true,
  getVersion: () => ipcRenderer.invoke('app:get-version'),

  update: {
    installFromZip: () => ipcRenderer.invoke('update:installFromZip'),
    checkNow: () => ipcRenderer.invoke('update:checkNow')
  },

  exportMeeting: (kind, item) => ipcRenderer.invoke('export:meeting', { kind: kind, item: item }),

  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),

  onMenuAction: (callback) => {
    ipcRenderer.removeAllListeners('menu:install-update');
    ipcRenderer.on('menu:install-update', () => callback('install-update'));
  }
});
