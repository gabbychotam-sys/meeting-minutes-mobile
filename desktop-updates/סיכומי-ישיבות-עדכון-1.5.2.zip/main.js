const { app, BrowserWindow, Menu, dialog, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFileSync } = require('child_process');
const { Document, Packer, Paragraph, HeadingLevel, TextRun, AlignmentType } = require('docx');

const appVersion = require('./package.json').version;
const DESKTOP_VERSION_URL = 'https://gabbychotam-sys.github.io/meeting-minutes-mobile/desktop-version.json';

let mainWindow = null;

function copyDirRecursive(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  for (const item of fs.readdirSync(src)) {
    const s = path.join(src, item), d = path.join(dest, item);
    if (fs.statSync(s).isDirectory()) copyDirRecursive(s, d);
    else fs.copyFileSync(s, d);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 820,
    minWidth: 860,
    minHeight: 560,
    title: 'סיכומי ישיבות',
    icon: path.join(__dirname, 'icons', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  buildMenu();
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

function buildMenu() {
  const template = [
    {
      label: 'עזרה',
      submenu: [
        { label: 'גרסה: v' + appVersion, enabled: false },
        { type: 'separator' },
        { label: 'התקן עדכון מקובץ ZIP...', click: () => mainWindow.webContents.send('menu:install-update') },
        { label: 'בדוק עדכון עכשיו...', click: () => checkForDesktopUpdate(true) },
        { type: 'separator' },
        {
          label: 'אודות',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'אודות',
              message: 'סיכומי ישיבות',
              detail: 'גרסה: v' + appVersion + '\n\nכל הנתונים מסונכרנים דרך Firebase — אין קובץ נתונים מקומי.',
              buttons: ['סגור']
            });
          }
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  createWindow();
  setTimeout(() => checkForDesktopUpdate(false), 5000);
  setInterval(() => checkForDesktopUpdate(false), 30 * 60 * 1000);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ═══════════════════════════════════════════════════════════════════
// Automatic update check — polls a small version manifest hosted on the
// same GitHub Pages site as the mobile app, same idea as the mobile
// auto-update poller. Runs on startup + every 30 min, plus on demand via
// the menu. `interactive` controls whether "you're already up to date" /
// error dialogs show (only for the manual menu trigger — silent otherwise).
// ═══════════════════════════════════════════════════════════════════

function cmpVersions(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0); }
  return 0;
}

async function checkForDesktopUpdate(interactive) {
  let manifest;
  try {
    const resp = await fetch(DESKTOP_VERSION_URL, { cache: 'no-store' });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    manifest = await resp.json();
  } catch (e) {
    if (interactive) dialog.showErrorBox('בדיקת עדכון נכשלה', 'לא ניתן היה לבדוק אם יש גרסה חדשה: ' + e.message);
    return;
  }

  if (!manifest.version || !manifest.zipUrl || cmpVersions(manifest.version, appVersion) <= 0) {
    if (interactive) {
      dialog.showMessageBox(mainWindow, {
        type: 'info', title: 'עדכון תוכנה',
        message: 'אתה כבר מריץ את הגרסה העדכנית ביותר',
        detail: 'גרסה מותקנת: v' + appVersion,
        buttons: ['סגור']
      });
    }
    return;
  }

  const confirm = await dialog.showMessageBox(mainWindow, {
    type: 'info', title: 'גרסה חדשה זמינה',
    message: 'סיכומי ישיבות v' + manifest.version + ' זמינה (מותקן: v' + appVersion + ')',
    detail: manifest.notes || '',
    buttons: ['הורד והתקן', 'מאוחר יותר'],
    defaultId: 0, cancelId: 1
  });
  if (confirm.response !== 0) return;

  try {
    await downloadAndInstallUpdate(manifest.zipUrl);
    app.relaunch();
    app.exit(0);
  } catch (e) {
    dialog.showErrorBox('העדכון נכשל', e.message || String(e));
  }
}

async function downloadAndInstallUpdate(zipUrl) {
  const resp = await fetch(zipUrl);
  if (!resp.ok) throw new Error('הורדת העדכון נכשלה: HTTP ' + resp.status);
  const buffer = Buffer.from(await resp.arrayBuffer());
  const tmpZip = path.join(os.tmpdir(), 'meetingminutes-download-' + Date.now() + '.zip');
  fs.writeFileSync(tmpZip, buffer);
  try {
    await installUpdateFromZip(tmpZip);
  } finally {
    try { fs.unlinkSync(tmpZip); } catch (e) {}
  }
}

ipcMain.handle('update:checkNow', () => checkForDesktopUpdate(true));

// Electron's bundled Chromium has webkitSpeechRecognition deliberately blocked
// by Google outside real Chrome (confirmed: fails with error:not-allowed
// regardless of permissions or secure context — no in-app fix exists). So mic
// dictation opens the same physical mic through the system's real browser
// instead, on a page that writes live into the same Firebase path the desktop
// already listens on — see dictate.html in the mobile repo.
ipcMain.handle('shell:openExternal', (e, url) => {
  if (!/^https:\/\/gabbychotam-sys\.github\.io\//.test(url)) return;
  shell.openExternal(url);
});

// ═══════════════════════════════════════════════════════════════════
// In-app update: install a ZIP over the running app, then relaunch.
// The ZIP must contain (at its root, or one folder down): renderer/,
// main.js, preload.js, package.json — the same layout electron-builder
// packs with asar:false, so it lands straight over __dirname.
// ═══════════════════════════════════════════════════════════════════

ipcMain.handle('app:get-version', () => appVersion);

ipcMain.handle('update:installFromZip', async () => {
  const r = await dialog.showOpenDialog(mainWindow, {
    title: 'בחר קובץ עדכון (.zip)',
    filters: [{ name: 'MeetingMinutes Update', extensions: ['zip'] }],
    properties: ['openFile']
  });
  if (r.canceled || !r.filePaths.length) return { ok: false, error: 'cancelled' };

  const confirm = await dialog.showMessageBox(mainWindow, {
    type: 'warning',
    title: 'התקנת עדכון',
    message: 'התוכנה תתעדכן ותפתח מחדש',
    detail: 'הקובץ:\n' + r.filePaths[0] + '\n\nהאם להמשיך?',
    buttons: ['התקן ועדכן', 'ביטול'],
    defaultId: 0, cancelId: 1
  });
  if (confirm.response !== 0) return { ok: false, error: 'cancelled' };

  try {
    await installUpdateFromZip(r.filePaths[0]);
    app.relaunch();
    app.exit(0);
    return { ok: true };
  } catch (e) {
    dialog.showErrorBox('עדכון נכשל', e.message || String(e));
    return { ok: false, error: e.message };
  }
});

async function installUpdateFromZip(zipPath) {
  const targetDir = __dirname;
  const stagingDir = path.join(os.tmpdir(), 'meetingminutes-update-' + Date.now());
  fs.mkdirSync(stagingDir, { recursive: true });

  try {
    execFileSync('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-Command',
      `Expand-Archive -Path "${zipPath.replace(/"/g, '`"')}" -DestinationPath "${stagingDir.replace(/"/g, '`"')}" -Force`
    ], { stdio: 'pipe' });
  } catch (e) {
    throw new Error('הוצאת ה-ZIP נכשלה: ' + (e.stderr ? e.stderr.toString() : e.message));
  }

  const candidateRoots = [
    stagingDir,
    ...fs.readdirSync(stagingDir).map(d => path.join(stagingDir, d)).filter(p => fs.statSync(p).isDirectory())
  ];
  let updateRoot = null;
  for (const root of candidateRoots) {
    if (fs.existsSync(path.join(root, 'renderer', 'index.html'))) {
      updateRoot = root;
      break;
    }
  }
  if (!updateRoot) throw new Error('הקובץ אינו עדכון תקין (חסר renderer/index.html)');

  const itemsToCopy = ['renderer', 'main.js', 'preload.js', 'package.json'];
  for (const item of itemsToCopy) {
    const src = path.join(updateRoot, item);
    if (!fs.existsSync(src)) continue;
    const dest = path.join(targetDir, item);
    if (fs.statSync(src).isDirectory()) {
      copyDirRecursive(src, dest);
    } else {
      fs.copyFileSync(src, dest);
    }
  }

  try { fs.rmSync(stagingDir, { recursive: true, force: true }); } catch (e) {}
}

// ═══════════════════════════════════════════════════════════════════
// Export a saved meeting to Word (.docx) or PDF, including title +
// participants as a header. Handles both the new {title,participants,
// topics:[{name,summary,segments}]} shape and legacy {summary,transcript}.
// ═══════════════════════════════════════════════════════════════════

function safeFileName(s) {
  return String(s || 'ישיבה').replace(/[\\/:*?"<>|]/g, '-').trim().slice(0, 80) || 'ישיבה';
}

function escapeHtmlMain(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function buildExportHtml(item) {
  const title = item.title || ('ישיבה מתאריך ' + (item.date || ''));
  let body = `<h1>${escapeHtmlMain(title)}</h1><div class="meta">📅 ${escapeHtmlMain(item.date || '')}</div>`;
  if (item.participants && item.participants.length) {
    body += `<div class="meta"><b>משתתפים:</b> ${item.participants.map(escapeHtmlMain).join(', ')}</div>`;
  }
  if (item.topics) {
    item.topics.forEach(t => {
      body += `<h2>${escapeHtmlMain(t.name)}</h2><div class="summary">${escapeHtmlMain(t.summary || '').replace(/\n/g, '<br>')}</div>`;
      if (t.segments && t.segments.length) {
        body += '<div class="transcript">' + t.segments.map(s =>
          `<div>${s.speaker ? `<b>${escapeHtmlMain(s.speaker)}:</b> ` : ''}${escapeHtmlMain(s.text)}</div>`
        ).join('') + '</div>';
      }
    });
  } else {
    body += `<h2>סיכום</h2><div class="summary">${escapeHtmlMain(item.summary || '').replace(/\n/g, '<br>')}</div>`;
    body += `<h2>תמלול מלא</h2><div class="transcript">${escapeHtmlMain(item.transcript || '').replace(/\n/g, '<br>')}</div>`;
  }
  return `<!DOCTYPE html><html lang="he" dir="rtl"><head><meta charset="UTF-8"><style>
    body { font-family: 'Segoe UI', Arial, sans-serif; direction: rtl; padding: 30px 40px; color: #1a1a2e; }
    h1 { color: #0f3460; margin-bottom: 4px; }
    h2 { color: #0f3460; margin-top: 26px; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
    .meta { color: #555; font-size: 13px; margin-bottom: 4px; }
    .summary { line-height: 1.8; white-space: pre-wrap; }
    .transcript { background: #f7f8fb; border-radius: 8px; padding: 12px 14px; margin-top: 8px; font-size: 12.5px; color: #444; }
    .transcript div { margin-bottom: 4px; }
  </style></head><body>${body}</body></html>`;
}

async function exportToPdf(item) {
  const defaultName = safeFileName(item.title || item.date) + '.pdf';
  const r = await dialog.showSaveDialog(mainWindow, {
    title: 'ייצוא ל-PDF', defaultPath: path.join(app.getPath('downloads'), defaultName),
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (r.canceled || !r.filePath) return { canceled: true };

  const tmpHtml = path.join(os.tmpdir(), 'mm-export-' + Date.now() + '.html');
  fs.writeFileSync(tmpHtml, buildExportHtml(item), 'utf8');

  const win = new BrowserWindow({ show: false, webPreferences: { offscreen: true } });
  try {
    await win.loadFile(tmpHtml);
    const buffer = await win.webContents.printToPDF({ printBackground: true, pageSize: 'A4' });
    fs.writeFileSync(r.filePath, buffer);
    return { ok: true, filePath: r.filePath };
  } finally {
    win.destroy();
    try { fs.unlinkSync(tmpHtml); } catch (e) {}
  }
}

// opens the OS print dialog (which includes its own preview pane) instead of
// silently saving a file - webContents.print() is Chromium's own dialog, same
// one Ctrl+P shows in a real browser
function printItemPreview(item) {
  return new Promise((resolve, reject) => {
    const tmpHtml = path.join(os.tmpdir(), 'mm-print-' + Date.now() + '.html');
    fs.writeFileSync(tmpHtml, buildExportHtml(item), 'utf8');
    const win = new BrowserWindow({ show: false });
    win.loadFile(tmpHtml).then(() => {
      win.webContents.print({ printBackground: true }, (success, failureReason) => {
        win.destroy();
        try { fs.unlinkSync(tmpHtml); } catch (e) {}
        if (success || failureReason === 'cancelled') resolve({ ok: true });
        else reject(new Error(failureReason));
      });
    }).catch((err) => { win.destroy(); try { fs.unlinkSync(tmpHtml); } catch (e2) {} reject(err); });
  });
}

function bulletParagraphs(text) {
  const lines = String(text || '').split('\n').map(l => l.replace(/^•\s*/, '').trim()).filter(Boolean);
  if (!lines.length) return [new Paragraph({ text: '(אין תוכן)', alignment: AlignmentType.RIGHT, bidirectional: true })];
  return lines.map(l => new Paragraph({ text: '• ' + l, alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { after: 100 } }));
}

async function exportToWord(item) {
  const defaultName = safeFileName(item.title || item.date) + '.docx';
  const r = await dialog.showSaveDialog(mainWindow, {
    title: 'ייצוא ל-Word', defaultPath: path.join(app.getPath('downloads'), defaultName),
    filters: [{ name: 'Word', extensions: ['docx'] }]
  });
  if (r.canceled || !r.filePath) return { canceled: true };

  const children = [];
  const title = item.title || ('ישיבה מתאריך ' + (item.date || ''));
  children.push(new Paragraph({ text: title, heading: HeadingLevel.TITLE, alignment: AlignmentType.RIGHT, bidirectional: true }));
  children.push(new Paragraph({ text: '📅 ' + (item.date || ''), alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { after: 200 } }));
  if (item.participants && item.participants.length) {
    children.push(new Paragraph({
      alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { after: 300 },
      children: [new TextRun({ text: 'משתתפים: ', bold: true }), new TextRun({ text: item.participants.join(', ') })]
    }));
  }

  if (item.topics) {
    item.topics.forEach(t => {
      children.push(new Paragraph({ text: t.name, heading: HeadingLevel.HEADING_2, alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 300, after: 100 } }));
      children.push(...bulletParagraphs(t.summary));
      if (t.segments && t.segments.length) {
        children.push(new Paragraph({ alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 150 }, children: [new TextRun({ text: 'תמלול:', italics: true })] }));
        t.segments.forEach(s => {
          children.push(new Paragraph({
            alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { after: 60 },
            children: s.speaker ? [new TextRun({ text: s.speaker + ': ', bold: true }), new TextRun({ text: s.text })] : [new TextRun({ text: s.text })]
          }));
        });
      }
    });
  } else {
    children.push(new Paragraph({ text: 'סיכום', heading: HeadingLevel.HEADING_2, alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 200, after: 100 } }));
    children.push(...bulletParagraphs(item.summary));
    children.push(new Paragraph({ text: 'תמלול מלא', heading: HeadingLevel.HEADING_2, alignment: AlignmentType.RIGHT, bidirectional: true, spacing: { before: 300, after: 100 } }));
    children.push(new Paragraph({ text: item.transcript || '', alignment: AlignmentType.RIGHT, bidirectional: true }));
  }

  const doc = new Document({ sections: [{ children }] });
  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(r.filePath, buffer);
  return { ok: true, filePath: r.filePath };
}

ipcMain.handle('export:meeting', async (e, { kind, item }) => {
  try {
    if (kind === 'pdf') return await exportToPdf(item);
    if (kind === 'word') return await exportToWord(item);
    if (kind === 'print') return await printItemPreview(item);
    return { ok: false, error: 'unknown export kind' };
  } catch (err) {
    return { ok: false, error: err.message || String(err) };
  }
});
